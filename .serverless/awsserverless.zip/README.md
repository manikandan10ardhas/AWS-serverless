# serverless

I have used this project to learn AWS serverless framework completely...

How to install serverless, just run the command 

npm install -g serverless

For configure the AWS account, run the command

Serverless config credentials --provider aws --key ACCESSKEY --secret SECRETKEY --profile manikandan55

To create serverless project, run the command

Serverless create --template aws-nodejs --path serverlessProject

What is S3 bucket?
S3 bucket is object storage device which is used to store the images, files and videos. A bucket is container for objects. We can store any file in s3 bucket including metadata.